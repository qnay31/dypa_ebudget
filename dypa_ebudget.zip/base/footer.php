<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>Ebudgeting Dompet Yatim Piatu Amanah 2022</span></strong>. All Rights Reserved
    </div>
</footer><!-- End Footer -->