<?php 
session_start();

error_reporting(0);
require '../../function.php';

$unik     = $_GET["id_unik"];
$periode  = $_GET["id_p"]; 
$query  = mysqli_query($conn, "SELECT * FROM 2022_program WHERE id = '$unik' AND MONTH(tgl_pengajuan) = '$periode' ");
$data   = mysqli_fetch_assoc($query);
$program= $data["program"];
$deskripsi   = mysqli_real_escape_string($conn, $data["deskripsi"]);
$ip     = get_client_ip();
$date   = date("Y-m-d H:i:s");

// die(var_dump($posisi));

$result2 = mysqli_query($conn, "INSERT INTO 2022_log_aktivity VALUES('', '$_SESSION[nama]', '$_SESSION[posisi]', '$ip', '$date', '$_SESSION[nama] Divisi $_SESSION[posisi] Telah Mengkonfirmasi Anggaran $program dengan perencanaan $deskripsi')");


$update = mysqli_query($conn, "UPDATE `2022_program` SET 
            `status`  ='OK'
            WHERE id    = '$unik' "); 

// die(var_dump($update));
if ($update !== true) {
    echo "<script>
alert('Data Tidak Berhasil Dikonfirmasi');
document.location.href = '../../admin/$_SESSION[username].php?id_checklist=checklist_pengajuan';
</script>";

} else {
echo "<script>
alert('Data Anggaran Berhasil Dikonfirmasi');
document.location.href = '../../admin/$_SESSION[username].php?id_checklist=checklist_pengajuan';
</script>";
}


?>