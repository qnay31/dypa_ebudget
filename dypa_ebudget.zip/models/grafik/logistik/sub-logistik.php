<div class="card-body">
    <h5 class="card-title">GRAFIK LOGISTIK</h5>
    <!-- Bar Chart -->
    <h5 class="card-title text-center">LOGISTIK GLOBAL</h5>
    <div class="chart-bar">
        <canvas id="chartBar_global_logistik"></canvas>
    </div>
    <!-- End Bar Chart -->
</div>