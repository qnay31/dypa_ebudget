<div class="card-body">
    <h5 class="card-title">GRAFIK PEMASUKAN</h5>
    <div class="row">
        <div class="col-xl-12 col-md-12">
            <div class="card">
                <h5 class="card-title text-center">INCOME MEDIA SOSIAL GLOBAL</h5>
                <div class="chart-bar">
                    <canvas id="chartBar_global_incMedia"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12 col-md-12">
            <div class="card">
                <h5 class="card-title text-center">INCOME NON RESI</h5>
                <div class="chart-bar">
                    <canvas id="chartBar_nonResi_incMedia"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- End Bar Chart -->
</div>